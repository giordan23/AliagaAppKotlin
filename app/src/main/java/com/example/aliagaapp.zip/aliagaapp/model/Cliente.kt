package com.example.aliagaapp.model

data class Cliente(
    val dni: String,
    val nombreCompleto: String,
    var telefono: Int
)
